<div id="dashboard-form-content">
  <div class="table-wrapper"><?php print $tables; ?></div>
</div>
<div id="dashboard-form-links"><?php print $links; ?></div><div class="clear-block"></div>
<?php print drupal_render_children($form) ?>




