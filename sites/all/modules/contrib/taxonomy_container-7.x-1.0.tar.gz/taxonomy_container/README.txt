Taxonomy container
==================

-- SUMMARY --
The taxonomy container module allows you to organize containers using taxonomy terms.
This module just adds an extra widget called �Select list (with groups)� to term reference fields.

-- REQUIREMENTS --
  * Taxonomy module enabled

-- INSTALLATION --
  * Place the entire taxonomy_container directory into your Drupal sites/all/modules/ directory.
  * Enable the taxonomy container module.

-- CONTACT --
Current maintainer: Chi - http://drupal.org/user/556138
Testing and feedback are welcome.