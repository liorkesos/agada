README.txt
==========

Usage
=====

See: http://drupal.org/project/pdf_reader

Additional Support
=================
For support, please create a support request for this module's project:
  http://drupal.org/project/pdf_reader

Support questions by email to the module maintainer will be simply ignored. Use the issue tracker.

====================================================================
Victor Castell, victor.castell at season.es, http://season.es